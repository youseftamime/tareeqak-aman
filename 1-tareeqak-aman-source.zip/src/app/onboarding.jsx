import React, { useState } from 'react';
import { View, StyleSheet, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, FONTS } from '../theme';
import { T } from '../components/T';
import { PrimaryButton } from '../components/ui';
import { IconTile } from '../components/Icon';

const ONBOARDING_KEY = 'onboarding_seen_v1';

const SLIDES = [
  {
    icon: 'megaphone',
    title: 'بلّغ عن مشكلة في ثواني',
    text: 'صوّر الحفرة أو العطل، حدد مكانه على الخريطة، وابعت البلاغ — من غير أي مكالمات أو ورق.',
  },
  {
    icon: 'map',
    title: 'شوف كل البلاغات على الخريطة',
    text: 'خريطة تفاعلية بتعرض بلاغات الناس حواليك، ملوّنة حسب حالة كل بلاغ: جديد، قيد العمل، أو اتحل.',
  },
  {
    icon: 'search',
    title: 'تابع بلاغك برقم مرجعي',
    text: 'كل بلاغ ليه رقم مرجعي خاص بيه — ادخل بيه في أي وقت وشوف وصل لأي مرحلة لحد ما يتحل.',
  },
];

export async function hasSeenOnboarding() {
  try {
    return (await AsyncStorage.getItem(ONBOARDING_KEY)) === '1';
  } catch (e) {
    return true;
  }
}

async function markOnboardingSeen() {
  try {
    await AsyncStorage.setItem(ONBOARDING_KEY, '1');
  } catch (e) {}
}

export default function OnboardingScreen() {
  const router = useRouter();
  const [page, setPage] = useState(0);
  const last = page === SLIDES.length - 1;
  const slide = SLIDES[page];

  async function finish() {
    await markOnboardingSeen();
    router.replace('/auth');
  }

  function next() {
    if (last) {
      finish();
      return;
    }
    setPage(page + 1);
  }

  return (
    <View style={styles.wrap}>
      <LinearGradient colors={[colors.navy, colors.navySoft]} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
        <View style={styles.topRow}>
          <Pressable onPress={finish} hitSlop={12}>
            <T style={styles.skip}>تخطي</T>
          </Pressable>
        </View>

        {/* State-driven pager: identical on web and native, immune to RTL
            horizontal-scroll origin differences between platforms. */}
        <View style={styles.slideArea}>
          <View key={slide.title} style={styles.slide}>
            <IconTile name={slide.icon} size={96} iconSize={44} color={colors.teal} bg={colors.tealPale} style={{ borderRadius: 30, marginBottom: 24 }} />
            <T style={styles.title}>{slide.title}</T>
            <T style={styles.text}>{slide.text}</T>
          </View>
        </View>

        <View style={styles.dots}>
          {SLIDES.map((_, i) => (
            <Pressable key={i} onPress={() => setPage(i)} hitSlop={8}>
              <View style={[styles.dot, i === page && styles.dotActive]} />
            </Pressable>
          ))}
        </View>

        <View style={styles.footer}>
          <PrimaryButton
            title={last ? 'ابدأ دلوقتي' : 'التالي'}
            onPress={next}
            style={{ backgroundColor: colors.teal }}
          />
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.navy },
  topRow: { alignItems: 'flex-start', paddingHorizontal: 20, paddingVertical: 10 },
  skip: { color: '#9FB3C8', fontSize: 15, fontFamily: FONTS.semiBold },
  slideArea: { flexGrow: 1, justifyContent: 'center' },
  slide: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 36 },
  title: { color: colors.white, fontSize: 24, fontFamily: FONTS.black, textAlign: 'center' },
  text: {
    color: '#B8C7D9',
    fontSize: 15.5,
    textAlign: 'center',
    lineHeight: 26,
    marginTop: 14,
  },
  dots: { flexDirection: 'row-reverse', justifyContent: 'center', gap: 8, marginVertical: 24 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.25)' },
  dotActive: { width: 24, backgroundColor: colors.tealLight },
  footer: { paddingHorizontal: 24, paddingBottom: 16 },
});
