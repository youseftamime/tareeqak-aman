// رقم دخول لوحة تحكم المشرفين — غيّره لأي رقم يعجبك
export const ADMIN_PIN = 'PASTE_YOUR_ADMIN_PIN';
